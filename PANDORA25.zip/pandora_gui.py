"""
pandora_gui.py
Simple Tkinter-based GUI for user control.
Philosophy: Clarity, ease of control, moderate feedback.
"""
import tkinter as tk

class App(tk.Tk):
    def __init__(self):
        # Setup simple window with Start/Stop, status display
        pass