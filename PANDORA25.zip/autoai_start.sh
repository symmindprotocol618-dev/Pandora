#!/bin/bash
echo "==== Booted: Starting AIOS/Pandora System ===="
cd ~/AIOS_Pandora                # Change to your AI directory, adjust as needed
python3 Launch_AI.py